import org.apache.spark.SparkConf
import org.apache.spark.sql.SparkSession

object WordCount {
  def main(args: Array[String]): Unit = {
    // Create Spark configuration
    val conf = new SparkConf().setAppName("WordCount").setMaster("local[*]")
    
    // Create Spark session
    val spark = SparkSession.builder().config(conf).getOrCreate()
    
    // Read input text file
    val inputFile = "input.txt" // Replace with the path to your input file
    val inputRDD = spark.sparkContext.textFile(inputFile)
    
    // Split each line into words and count occurrence of each word
    val wordCountsRDD = inputRDD
      .flatMap(_.split("\\s+")) // Split each line into words
      .map(word => (word, 1)) // Map each word to (word, 1)
      .reduceByKey(_ + _) // Reduce by key to count occurrences
    
    // Print word counts
    wordCountsRDD.foreach(println)
    
    // Stop Spark session
    spark.stop()
  }
}


To execute the above program

scalac -classpath spark-core_2.12-3.2.1.jar WordCount.scala

scala -classpath spark-core_2.12-3.2.1.jar:. WordCount

